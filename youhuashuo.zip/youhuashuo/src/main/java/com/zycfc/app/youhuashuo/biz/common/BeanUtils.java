
package com.zycfc.app.youhuashuo.biz.common;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;

/**
 * <h1>Bean实用类</h1>
 * <p>
 * 主要用于进行DataEntity类型的属性拷贝
 * </p>
 *
 */
/*
 * Modify history $Log$
 */
public class BeanUtils {
	/**
	 * Set方法位置
	 */
	public static final int SET_INDEX = 3;
	/**
	 * 保留方法名
	 */
	private static final String[] RESERVED_METHOD_NAMES = { "get", "getBigDecimal", "getBigInteger", "getBoolean",
			"getByte", "getBytes", "getChangeSummary", "getChar", "getClass", "getContainer", "getContainmentProperty",
			"getDataGraph", "getDataEntity", "getDate", "getDouble", "getFloat", "getInstanceProperties",
			"getInstanceProperty", "getInt", "getList", "getLong", "getProperty", "getRootObject", "getSequence",
			"getShort", "getString", "getType" };

	/**
	 * 保留方法名
	 */
	private static List<String> RESERVED_METHOD_NAME_LIST = Arrays.asList(RESERVED_METHOD_NAMES);

	/**
	 * get方法
	 */
	private static String GET_METHOD_PREFIX = "get";

	/**
	 * set方法
	 */

	/**
	 * 将源对象的属性复制到目标对象
	 * 
	 * @param source
	 *            源对象
	 * @param target
	 *            目标对象
	 */
	public static void copyProperties(Object source, Object target) {
		// 所有方法
		Method[] allMethods = source.getClass().getDeclaredMethods();
		// 循环
		for (Method method : allMethods) {
			// 如果是get方法
			if (method.getName().startsWith(GET_METHOD_PREFIX)
					&& !RESERVED_METHOD_NAME_LIST.contains(method.getName())) {
				Object value = invoceMethod(method, source);
				setValue(target, value, "set" + method.getName().substring(SET_INDEX), method);
			}
		}
	}

	/**
	 * 设置值到对应对象
	 * 
	 * @param target
	 * @param value
	 * @param methodName
	 * @param obatainValueMethod
	 *            获取值方法
	 */
	private static void setValue(Object target, Object value, String methodName, Method obatainValueMethod) {
		Method method = getMethod(target, value, methodName, obatainValueMethod.getReturnType());
		if (method != null) {
			try {
				method.invoke(target, new Object[] { value });
			} catch (IllegalArgumentException e) {
			} catch (IllegalAccessException e) {
			} catch (InvocationTargetException e) {
			}
		}
	}

	/**
	 * 获取给定方法
	 * 
	 * @param target
	 * @param value
	 * @param methodName
	 * @param valueClasses
	 *            值类型
	 * @return
	 */
	private static Method getMethod(Object target, Object value, String methodName, Class<?>... valueClasses) {
		Method method = null;
		if (value == null) {
			try {
				return target.getClass().getDeclaredMethod(methodName, valueClasses);
			} catch (SecurityException e) {
			} catch (NoSuchMethodException e) {
			}
			return null;
		}
		if (value instanceof Integer) {// 如果为Integer, 首先尝试使用int.class
			try {
				return target.getClass().getDeclaredMethod(methodName, new Class[] { int.class });
			} catch (SecurityException e) {
			} catch (NoSuchMethodException e) {
			}
		} else if (value instanceof Long) {// 如果为Long, 首先尝试使用long.class
			try {
				return target.getClass().getDeclaredMethod(methodName, new Class[] { long.class });
			} catch (SecurityException e) {
			} catch (NoSuchMethodException e) {
			}
		} else if (value instanceof java.sql.Date) {
			try {
				return target.getClass().getDeclaredMethod(methodName, new Class[] { java.util.Date.class });
			} catch (SecurityException e) {
			} catch (NoSuchMethodException e) {
			}
		}
		try {
			method = target.getClass().getDeclaredMethod(methodName, new Class[] { value.getClass() });
		} catch (SecurityException e) {
		} catch (NoSuchMethodException e) {
		}
		return method;
	}

	/**
	 * 调用方法并获取返回值
	 * 
	 * @param method
	 * @param target
	 * @return
	 */
	private static Object invoceMethod(Method method, Object target) {
		try {
			return method.invoke(target, new Object[] {});
		} catch (IllegalArgumentException e) {
		} catch (IllegalAccessException e) {
		} catch (InvocationTargetException e) {
		}
		return null;
	}

	/**
	 * 将源对象的属性复制到目标对象,不复制空值
	 * 
	 * @param source 源对象
	 * @param target 目标对象
	 */
	public static void setNullPropertiesSymbol(Object source, String symbol) {
		BeanWrapper src = new BeanWrapperImpl(source);
		java.beans.PropertyDescriptor[] pds = src.getPropertyDescriptors();
		for (java.beans.PropertyDescriptor pd : pds) {
			if ("java.lang.String".equals(pd.getPropertyType().getName())) {
				Object srcValue = src.getPropertyValue(pd.getName());
				if (null == srcValue) {
					src.setPropertyValue(pd.getName(), symbol);
				}
			}
		}

	}
}
