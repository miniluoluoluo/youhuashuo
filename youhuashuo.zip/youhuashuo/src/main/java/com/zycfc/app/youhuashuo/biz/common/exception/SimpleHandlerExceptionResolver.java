package com.zycfc.app.youhuashuo.biz.common.exception;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSONObject;

import com.zycfc.app.youhuashuo.biz.common.OptResult;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

public class SimpleHandlerExceptionResolver extends SimpleMappingExceptionResolver {
	
	public static final Logger logger = LoggerFactory.getLogger(SimpleHandlerExceptionResolver.class);
	
	private Boolean show_original_error_msg;

	@Override
	public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler,
			Exception ex) {
		logger.error("系统报错：", ex);
		if (handler instanceof HandlerMethod) {
			HandlerMethod handlerMethod = (HandlerMethod) handler;
			ResponseBody body = handlerMethod.getMethodAnnotation(ResponseBody.class);
			if(body == null) {
				return super.doResolveException(request, response, handler, ex);
			}else {
				String returnCode = "SYS-0002";
				String returnMsg = "系统正在开小差，请联系客服或者稍后再试！";
				if(ex instanceof MsgException) {
				   MsgException e = (MsgException) ex;
				   returnCode = e.getErrorCode();
				   if(show_original_error_msg) {
					   returnMsg = e.getErrorMessage();
					   if(null != returnMsg && returnMsg.length() > 50) {
						   returnMsg = returnMsg.substring(0, 50) + "...请联系客服或者稍后再试！";
					   }else {
						   returnMsg = returnMsg + " 请联系客服或者稍后再试！";
					   }
				   }else {
					   if("WXD014002".equals(returnCode) || "WXD015001".equals(returnCode)) {
						   returnMsg = e.getErrorMessage();
						   if(StringUtils.isNotBlank(returnMsg)) {
							   returnMsg = returnMsg.replaceFirst("业务处理-", ""); 
						   }
					   }else {
						   OptResult opt = new OptResult(returnCode);
						   returnMsg = opt.getReturnMsg();
					   }
				   }
				}
				ModelAndView mv = new ModelAndView(); 
				response.setStatus(HttpStatus.OK.value());   // 设置ContentType 
				response.setContentType(MediaType.APPLICATION_JSON_VALUE);	// 避免乱码 
				response.setCharacterEncoding("UTF-8"); 
				response.setHeader("Cache-Control", "no-cache, must-revalidate");   
				try { 
				  PrintWriter writer = response.getWriter();
				  JSONObject json = new JSONObject();
				  json.put("returnCode", returnCode);
				  json.put("returnMsg", returnMsg);
				  String result = json.toJSONString();
				  String userId = request.getHeader("userId");
				  writer.write(result);
				  writer.close();
				  logger.info("返回给前端的数据结果为：userId = {}, result ={}", userId, result);
			    } catch (IOException e) {    
				   e.printStackTrace();   
			    }
				return mv;
			}
		}else {
			return super.doResolveException(request, response, handler, ex);
		}
	}

	public Boolean getShow_original_error_msg() {
		return show_original_error_msg;
	}

	public void setShow_original_error_msg(Boolean show_original_error_msg) {
		this.show_original_error_msg = show_original_error_msg;
	}

}
