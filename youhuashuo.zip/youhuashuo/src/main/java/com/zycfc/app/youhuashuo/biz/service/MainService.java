package com.zycfc.app.youhuashuo.biz.service;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import com.google.common.base.Strings;
import com.google.common.collect.Maps;

/**
 * @Author : cpz
 * @Date : Create in 下午4:52 2018/8/23
 */
public class MainService {

    public static void main(String[] args) throws IOException {
        FileWriter fw = null;
        int i = 0;
        try {
            InputStreamReader ins = new InputStreamReader(
                new FileInputStream("/Users/chenpengzhan/Downloads/catalina.out-20180728"),
                "UTF-8"
            );
            File file = new File("/Users/chenpengzhan/Downloads/20180728");
            fw = new FileWriter(file);
            BufferedReader read = new BufferedReader(ins);
            while (read.ready()) {
                String sr = read.readLine();
                //if (sr.contains("11111111111")){
                //    sr.replace("=","未知");
                //    System.out.println(sr);
                //}
                //System.out.println(sr.split("\\| ")[1]);
                //String sn = sr.split("\\| ")[1];
                if (!sr.contains("dataType")){
                    continue;
                }
                String line = sr.split("\\| ")[1];
                if (line.contains("数据校验失败") || line.contains("868034036725083")){
                    System.out.println("数据校验失败");
                    continue;
                }
                String split = line.split("add ")[1];
                //System.out.println(split);
                String channel = "";
                if (split.startsWith("userId", 0)) {

                } else {
                    String substring = split.substring(0,7);
                    if (substring.equals("channel")){
                        channel = split.substring(9,11);
                        //System.out.println(channel);
                    }
                    String data = split.split("joson = ")[1];
                    //System.out.println(data);
                    String fd = data.substring(1, data.length());
                    //System.out.println(fd);
                    String ss = fd.substring(11, fd.length());

                    //System.out.println(ss);
                    String bb = ss.substring(0, ss.length() - 1);
                    //System.out.println(bb);
                    //System.out.println(bb);
                    //bb.replace("=","未知");
                    if (!bb.contains("linkmanList") || bb.contains("869377033639560")){
                        continue;
                    }

                    JSONArray objects = JSONArray.parseArray(bb);
                    //JSONObject jsonObject = JSONObject.parseObject(bb);
                    Map<String, Object> map = Maps.newHashMap();
                    JSONObject o = (JSONObject)objects.get(0);
                    if (Strings.isNullOrEmpty(o.getString("dataType"))){
                        continue;
                    }
                    if (o.getString("dataType").equals("09")) {
                        System.out.println(o.toString()+ i++);
                        //System.out.println(o.toString());
                        String deviceId = (String)o.get("deviceId");
                        String phone = (String)o.get("phone");
                        List<Map<String,Object>> linkmanList = (List<Map<String,Object>>)o.get("linkmanList");
                        System.out.println(linkmanList.toString());
                        if (phone.equals("13908571714")){
                            continue;
                        }

                        for (Map<String,Object> map1:linkmanList) {
                            List list = new ArrayList();
                            list.add(UUID.randomUUID()+"|^");
                            list.add(phone+"|^");
                            list.add(deviceId+"|^");
                            list.add(map1.get("name")+"|^");
                            list.add(map1.get("mobile")+"|^");
                            list.add(""+"|^");
                            list.add(""+"|^");
                            list.add(""+"|^");
                            list.add(""+"|^");
                            list.add(""+"|^");
                            list.add(""+"|^");
                            list.add(""+"|^");
                            list.add(""+"|^");
                            list.add(""+"|^");
                            list.add(channel+"|^");
                            list.add("2018-07-28"+"|^");
                            list.add("2018-07-28");
                            writeToTxt(list,fw);

                        }
                    }

                }

            }

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }




        public static void writeToTxt(List<Map<String,Object>> list,FileWriter fw ){

        //System.out.println(++i);
            Iterator iterator = list.iterator();
            BufferedWriter writer = null;
            try {
                writer = new BufferedWriter(fw);
                while(iterator.hasNext()){
                    writer.write(iterator.next().toString());
                }
                writer.newLine();//换行
                writer.flush();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }catch (IOException e) {
                e.printStackTrace();
            }//finally{
            //    try {
            //        writer.close();
            //        fw.close();
            //    } catch (IOException e) {
            //        e.printStackTrace();
            //    }
            //}
        }

    }

    //public static void writeToTxt( List list) {
    //    FileOutputStream outSTr = null;
    //    BufferedOutputStream Buff = null;
    //    String path = request.getSession().getServletContext().getRealPath(
    //        "upordown/down/model/magazinePub.txt");
    //    String tab = "  ";
    //    String enter = "\r\n";
    //    MagazineBean magazine;
    //    StringBuffer write;
    //    try {
    //        outSTr = new FileOutputStream(new File(path));
    //        Buff = new BufferedOutputStream(outSTr);
    //        for (int i = 0; i < list.size(); i++) {
    //            magazine = (MagazineBean) list.get(i);
    //            write = new StringBuffer();
    //            write.append("期刊名称：" + tab);
    //            write.append(delNull(magazine.getTenet()) + enter);
    //            write.append(enter);
    //            Buff.write(write.toString().getBytes("UTF-8"));
    //        }
    //        Buff.flush();
    //        Buff.close();
    //    } catch (Exception e) {
    //        e.printStackTrace();
    //    } finally {
    //        try {
    //            Buff.close();
    //            outSTr.close();
    //        } catch (Exception e) {
    //            e.printStackTrace();
    //        }
    //    }
    //}

