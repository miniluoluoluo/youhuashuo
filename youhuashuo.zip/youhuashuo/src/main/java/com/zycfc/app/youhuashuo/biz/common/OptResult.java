package com.zycfc.app.youhuashuo.biz.common;

import java.io.IOException;
import java.util.Properties;

import com.alibaba.fastjson.JSONObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;

/**
 * <h1>操作结果</h1>
 * User: 
 * Date: 16-5-9
 * Time: 下午9:50
 */
public class OptResult {

    /**
     * 错误码
     */
    private String returnCode;
    /**
     * 错误信息
     */
    private String returnMsg;
    
    /**
     * 前端跳转url
     * */
    private String url;
    /**
     * 返回的数据项
     */
    private Object data;
    /**
     * 错误码
     */
    private static Properties errorCodes;
    /**
     * Logger
     */
    private static Logger logger = LoggerFactory.getLogger(OptResult.class);

    /**
     * 初始化错误码
     */
    static {
        try {
            logger.debug("从类路径加载[errors.properties]文件...");
            errorCodes = PropertiesLoaderUtils.loadProperties(new ClassPathResource("errors.properties"));
            logger.info("加载错误码文件成功！");
        } catch (IOException ex) {
            logger.error("从资源文件[errors.properties]加载错误码文件错误!", ex);
        }
    }

    /**
     * 默认构造
     */
    public OptResult() {
    }
  

    /**
     * 默认构造
     */
    public OptResult(String returnCode) {
    	this.returnCode = returnCode;
    	if(returnCode != null) {
            this.returnMsg = errorCodes.getProperty(returnCode, "系统正在开小差，请联系客服或者稍后再试！");
        }
    }
    
    /**
     * 默认构造
     */
    public OptResult(String returnCode, String returnMsg, String url) {
    	this.returnCode = returnCode;
    	this.url = url;
    	this.returnMsg = returnMsg;
    	
    }
    /**
     * 默认构造
     */
    public OptResult(String returnCode, String url) {
    	this.returnCode = returnCode;
    	this.url = url;
    	if(returnCode != null) {
            this.returnMsg = errorCodes.getProperty(returnCode, "系统正在开小差，请联系客服或者稍后再试！");
        }
    	
    }

    public String getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
		if(returnCode != null) {
            this.returnMsg = errorCodes.getProperty(returnCode, "系统正在开小差，请联系客服或者稍后再试！");
        }
	}

	public String getReturnMsg() {
		return returnMsg;
	}

	public void setReturnMsg(String returnMsg) {
		this.returnMsg = returnMsg;
	}

	/**
	 * @return the data
	 */
	public Object getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(Object data) {
		this.data = data;
	}


	public String getUrl() {
		return url;
	}


	public void setUrl(String url) {
		this.url = url;
	}


	@Override
	public String toString() {
		return JSONObject.toJSONString(this);
	}
	
}
