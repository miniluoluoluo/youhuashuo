package com.zycfc.app.youhuashuo.biz.common;

import java.util.Properties;


public class ConfigHolder {
	
	private ConfigHolder() {
		
	}
	
	//public static String getValueByKey(String key) {
	//	return getValueByKey(key, null);
	//}
	//
	//public static String getValueByKey(String key,String defaultValue) {
	//	Properties	propertiesConfigHolder= (Properties) SpringContextHolder.getBean("propertiesConfigHolder");
	//	return propertiesConfigHolder.getProperty(key, defaultValue);
	//}
}
