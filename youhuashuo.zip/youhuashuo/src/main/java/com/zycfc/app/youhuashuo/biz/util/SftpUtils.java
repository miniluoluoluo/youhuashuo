package com.zycfc.app.youhuashuo.biz.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.Properties;
import java.util.Vector;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SftpUtils {
	private static Logger log = LoggerFactory.getLogger("app_media_log");
	private ChannelSftp sftp = null;
	private Channel channel = null;
	private Session sshSession = null;
	/**
	 * 关闭连接 
	 * @throws Exception
	 */
	public void  disconnect()  {  
        try{  
            if (sftp.isConnected()) {  
                sftp.disconnect();  
            }  
            if (channel.isConnected()) {  
                channel.disconnect();  
            }  
            if (sshSession.isConnected()) {  
            	sshSession.disconnect();  
            }  
        }catch(Exception e){  
        	log.error("SftpUtils关闭SFTP连接异常", e);
            throw Exceptions.unchecked(e);
        }  
     }  
	
	/**
	 * 连接sftp服务器
	 * 
	 * @param host
	 *            主机
	 * @param port
	 *            端口
	 * @param username
	 *            用户名
	 * @param password
	 *            密码
	 * @return
	 */
	public ChannelSftp connect(String host, int port, String username,
			String password,Integer outTime) {
		
		try {
			JSch jsch = new JSch();
			jsch.getSession(username, host, port);
			sshSession = jsch.getSession(username, host, port);
			sshSession.setPassword(password);
			Properties sshConfig = new Properties();
			sshConfig.put("StrictHostKeyChecking", "no");
			sshSession.setConfig(sshConfig);
			if(outTime!=null){
				sshSession.connect(outTime);
			}else{
				sshSession.connect();
			}
			channel = sshSession.openChannel("sftp");
			if(outTime!=null){
				channel.connect(outTime);
			}else{
				channel.connect();
			}
			sftp = (ChannelSftp) channel;
		} catch (Exception e) {
        	log.error("SftpUtils连接sftp服务器异常", e);
            throw Exceptions.unchecked(e);
		}
		return sftp;
	}

	/**
	 * 上传文件
	 * 
	 * @param directory
	 *            上传的目录
	 * @param uploadFile
	 *            要上传的文件
	 * @param sftp
	 */
	public void upload(String directory, String uploadFile, ChannelSftp sftp) {
		try {
			sftp.cd(directory);
			File file = new File(uploadFile);
			sftp.put(new FileInputStream(file), file.getName());
		} catch (Exception e) {
        	log.error("上传文件异常", e);
            throw Exceptions.unchecked(e);
		}
	}
	
	/**
	 * 上传文件
	 * 
	 * @param directory
	 *            上传的目录
	 * @param uploadFile
	 *            要上传的文件
	 * @param sftp
	 */
	public  void upload(String dstName, byte[] b, ChannelSftp sftp) {
		try {
			OutputStream out = sftp.put(dstName, ChannelSftp.OVERWRITE); // 使用OVERWRITE模式
			out.write(b);
			out.flush();
		} catch (Exception e) {
        	log.error("上传文件异常", e);
            throw Exceptions.unchecked(e);
		}
	}
	
	/**
	 * 下载文件
	 * 
	 * @param directory
	 *            下载目录
	 * @param downloadFile
	 *            下载的文件
	 * @param saveFile
	 *            存在本地的路径
	 * @param sftp
	 */
	public void download(String downloadFile,
			String saveFile, ChannelSftp sftp) {
		try {
			sftp.get(downloadFile,saveFile);
		} catch (Exception e) {
        	log.error("下载文件异常", e);
            throw Exceptions.unchecked(e);
		}
	}

	/**
	 * 删除文件
	 * 
	 * @param directory
	 *            要删除文件所在目录
	 * @param deleteFile
	 *            要删除的文件
	 * @param sftp
	 */
	public void delete(String directory, String deleteFile, ChannelSftp sftp) {
		try {
			sftp.cd(directory);
			sftp.rm(deleteFile);
		} catch (Exception e) {
        	log.error("删除文件异常", e);
            throw Exceptions.unchecked(e);
		}
	}

	/**
	 * 列出目录下的文件
	 * 
	 * @param directory
	 *            要列出的目录
	 * @param sftp
	 * @return
	 * @throws SftpException
	 */
	public Vector<?> listFiles(String directory, ChannelSftp sftp)
			throws SftpException {
		return sftp.ls(directory);
	}

}
