package com.zycfc.app.youhuashuo.biz.common;

public class Const {
	
	/**前后台交互API返回结果成功*/
	public final static String API_RETURN_CODE_SUCCESS = "000000";
	
	//电脑端标识
	public final static String API_CHANNEL_TYPE_H5 = "h5";
	

}
