package com.zycfc.app.youhuashuo.biz.common.cache;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;

import com.zycfc.app.youhuashuo.biz.util.ObjectUtils;
import org.springframework.cache.Cache;
import org.springframework.cache.support.SimpleValueWrapper;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.util.StringUtils;

/**
 * 系统缓存Redis实现，与Spring整合使用
 * 在Redis中缓存存储规则实际为：
 * put： K = name + "_" + key， V = value
 * hput: K = name, field = key, V =value
 * @author xuxiao
 *
 */
public class SystemRedisCache implements Cache {
	/**
	 * Redis
	 */
	private RedisTemplate<String, Object> redisTemplate;

	/**
	 * 缓存名称
	 */
	private String name;

	/**
	 * 缓存过期时间，
	 */
	private Long expire;
	
	/**
	 * 数据库索引0-15
	 */
	private Integer dbIndex;

	@Override
	public String getName() {
		return this.name;
	}

	@Override
	public Object getNativeCache() {
		return this.redisTemplate;
	}

	@Override
	public void put(final Object key, final Object value) {
		if (StringUtils.isEmpty(key) || StringUtils.isEmpty(value)) {
			return;
		} else {
			final String finalKey;
			if (key instanceof String) {
				finalKey = name + "_" + (String) key;
			} else {
				finalKey = name + "_" + key.toString();
			}
			if (!StringUtils.isEmpty(finalKey)) {
				final Object finalValue = value;
				redisTemplate.execute(new RedisCallback<Boolean>() {
					@Override
					public Boolean doInRedis(RedisConnection connection) {
						connection.select(dbIndex);
						connection.set(finalKey.getBytes(), ObjectUtils.serialize(finalValue));
						if(null != expire && expire > 0) {
							connection.expire(finalKey.getBytes(), expire);
						}
						return true;
					}
				});
			}
		}
	}
	
	/**
	 * 存储到Hash中
	 * @param key
	 * @param value
	 */
	public void hput(final Object key, final Object value) {
		if (StringUtils.isEmpty(key) || StringUtils.isEmpty(value)) {
			return;
		} else {
			final String finalKey;
			if (key instanceof String) {
				finalKey = (String) key;
			} else {
				finalKey = key.toString();
			}
			if (!StringUtils.isEmpty(finalKey)) {
				final Object finalValue = value;
				redisTemplate.execute(new RedisCallback<Boolean>() {
					@Override
					public Boolean doInRedis(RedisConnection connection) {
						connection.select(dbIndex);
						connection.hSet(name.getBytes(), finalKey.getBytes(), ObjectUtils.serialize(finalValue));
						if(null != expire && expire > 0) {
							connection.expire(name.getBytes(), expire);
						}
						return true;
					}
				});
			}
		}
	}
	
	/**
	 * 如果不存在key则put
	 */
	@Override
	public ValueWrapper putIfAbsent(Object key, Object value) {
		if (StringUtils.isEmpty(key) || StringUtils.isEmpty(value)) {
			return null;
		} else {
			final String finalKey;
			if (key instanceof String) {
				finalKey = name + "_" + (String) key;
			} else {
				finalKey = name + "_" + key.toString();
			}
			if (!StringUtils.isEmpty(finalKey)) {
				final Object finalValue = value;
				boolean in = redisTemplate.execute(new RedisCallback<Boolean>() {
					@Override
					public Boolean doInRedis(RedisConnection connection) {
						connection.select(dbIndex);
						if(!connection.exists(finalKey.getBytes())) {
							connection.set(finalKey.getBytes(), ObjectUtils.serialize(finalValue));
							if(null != expire && expire > 0) {
								connection.expire(finalKey.getBytes(), expire);
							}
							return true;
						}else {
							return false;
						}
					}
				});
				if(in) {
					return new SimpleValueWrapper(value);
				}else {
					return null;
				}
			}else {
				return null;
			}
		}
	}

	@Override
	public ValueWrapper get(Object key) {
		if (StringUtils.isEmpty(key)) {
			return null;
		} else {
			final String finalKey;
			if (key instanceof String) {
				finalKey = name + "_" + (String) key;
			} else {
				finalKey = name + "_" + key.toString();
			}
			Object object = null;
			object = redisTemplate.execute(new RedisCallback<Object>() {
				public Object doInRedis(RedisConnection connection) throws DataAccessException {
					connection.select(dbIndex);
					byte[] key = finalKey.getBytes();
					byte[] value = connection.get(key);
					if (value == null) {
						return null;
					}
					return ObjectUtils.unserialize(value);
				}
			});
			return (object != null ? new SimpleValueWrapper(object) : null);
		}
	}
	
	/**
	 * 从Hash中获取Value
	 * @param key
	 * @return
	 */
	public ValueWrapper hget(Object key) {
		if (StringUtils.isEmpty(key)) {
			return null;
		} else {
			final String finalKey;
			if (key instanceof String) {
				finalKey = (String) key;
			} else {
				finalKey = key.toString();
			}
			Object object = null;
			object = redisTemplate.execute(new RedisCallback<Object>() {
				public Object doInRedis(RedisConnection connection) throws DataAccessException {
					connection.select(dbIndex);
					byte[] key = finalKey.getBytes();
					byte[] value = connection.hGet(name.getBytes(), key);
					if (value == null) {
						return null;
					}
					return ObjectUtils.unserialize(value);
				}
			});
			return (object != null ? new SimpleValueWrapper(object) : null);
		}
	}
	
	/**
	 * 从Hash中获取全部Value
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> hgetAll() {
		final Map<String, Object> map = new HashMap<String, Object>();
		Object obj = null;
		obj = redisTemplate.execute(new RedisCallback<Object>() {
			public Object doInRedis(RedisConnection connection) throws DataAccessException {
				connection.select(dbIndex);
				Map<byte[], byte[]> values = connection.hGetAll(name.getBytes());
				if (values == null) {
					return null;
				}
				for(Map.Entry<byte[], byte[]> entry : values.entrySet()) {
					String key = new String(entry.getKey());
					Object value = ObjectUtils.unserialize(entry.getValue());
					map.put(key, value);
				}
				return map;
			}
		});
		if(null == obj) {
		   return null;
		}else {
		   return (Map<String, Object>) obj;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> T get(Object key, Class<T> type) {
		if (StringUtils.isEmpty(key) || null == type) {
			return null;
		} else {
			final String finalKey;
			final Class<T> finalType = type;
			if (key instanceof String) {
				finalKey = name + "_" + (String) key;
			} else {
				finalKey = name + "_" + key.toString();
			}
			final Object object = redisTemplate.execute(new RedisCallback<Object>() {
				public Object doInRedis(RedisConnection connection) throws DataAccessException {
					connection.select(dbIndex);
					byte[] key = finalKey.getBytes();
					byte[] value = connection.get(key);
					if (value == null) {
						return null;
					}
					return ObjectUtils.unserialize(value);
				}
			});
			if (finalType != null && finalType.isInstance(object) && null != object) {
				return (T) object;
			} else {
				return null;
			}
		}
	}
	
	/**
	 * 从Hash中获取
	 * @param key
	 * @param type
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public <T> T hget(Object key, Class<T> type) {
		if (StringUtils.isEmpty(key) || null == type) {
			return null;
		} else {
			final String finalKey;
			final Class<T> finalType = type;
			if (key instanceof String) {
				finalKey = (String) key;
			} else {
				finalKey = key.toString();
			}
			final Object object = redisTemplate.execute(new RedisCallback<Object>() {
				public Object doInRedis(RedisConnection connection) throws DataAccessException {
					connection.select(dbIndex);
					byte[] key = finalKey.getBytes();
					byte[] value = connection.hGet(name.getBytes(), key);
					if (value == null) {
						return null;
					}
					return ObjectUtils.unserialize(value);
				}
			});
			if (finalType != null && finalType.isInstance(object) && null != object) {
				return (T) object;
			} else {
				return null;
			}
		}
	}
	
	@Override
	public <T> T get(Object key, Callable<T> valueLoader) {
		return null;
	}

	/*
	 * 根据Key 删除缓存
	 */
	@Override
	public void evict(Object key) {
		if (null != key) {
			final String finalKey;
			if (key instanceof String) {
				finalKey = name + "_" + (String) key;
			} else {
				finalKey = name + "_" + key.toString();
			}
			if (!StringUtils.isEmpty(finalKey)) {
				redisTemplate.execute(new RedisCallback<Long>() {
					public Long doInRedis(RedisConnection connection) throws DataAccessException {
						connection.select(dbIndex);
						return connection.del(finalKey.getBytes());
					}
				});
			}
		}
	}
	
	/**
	 * 从Hash中删除
	 * @param key
	 */
	public void hevict(Object key) {
		if (null != key) {
			final String finalKey;
			if (key instanceof String) {
				finalKey = (String) key;
			} else {
				finalKey = key.toString();
			}
			if (!StringUtils.isEmpty(finalKey)) {
				redisTemplate.execute(new RedisCallback<Long>() {
					public Long doInRedis(RedisConnection connection) throws DataAccessException {
						connection.select(dbIndex);
						return connection.hDel(name.getBytes(), finalKey.getBytes());
					}
				});
			}
		}
	}

	/*
	 * 清除整个名称为name的缓存
	 * 当注解为@CacheEvict，且allEntries = true时调用
	 */
	@Override
	public void clear() {
		final byte[] keys = (name + "_*").getBytes();
		redisTemplate.execute(new RedisCallback<Long>() {
			public Long doInRedis(RedisConnection connection) throws DataAccessException {
				connection.select(dbIndex);
				Set<byte[]> sets = connection.keys(keys);
				if(null == sets || sets.size() == 0) {
					return 0L;
				}
				Long count = 0L;
				for(byte[] data : sets) {
					count = count + connection.del(data);
				}
				return count;
			}
		});
	}
	
	/**
	 * 清除名称为name的Hash缓存
	 * @param name
	 */
	public void hclear(String name) {
		final byte[] key = (name + "_").getBytes();
		redisTemplate.execute(new RedisCallback<Long>() {
			public Long doInRedis(RedisConnection connection) throws DataAccessException {
				connection.select(dbIndex);
				Set<byte[]> sets = connection.keys(key);
				if(null == sets || sets.size() == 0) {
					return 0L;
				}
				Long count = 0L;
				for(byte[] data : sets) {
					count = count + connection.hDel(key, data);
				}
				return count;
			}
		});
	}

	public RedisTemplate<String, Object> getRedisTemplate() {
		return redisTemplate;
	}

	public void setRedisTemplate(RedisTemplate<String, Object> redisTemplate) {
		this.redisTemplate = redisTemplate;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getExpire() {
		return expire;
	}

	public void setExpire(Long expire) {
		this.expire = expire;
	}

	public Integer getDbIndex() {
		return dbIndex;
	}

	public void setDbIndex(Integer dbIndex) {
		this.dbIndex = dbIndex;
	}
	
}
