package com.zycfc.app.youhuashuo.biz.common.config;

import java.sql.SQLException;

import com.alibaba.druid.pool.DruidDataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @Author : cpz
 * @Date : Create in 下午1:32 2018/8/13
 */

@Configuration
public class DataSourceConfiguration {
    private static Logger logger = LoggerFactory.getLogger(DataSourceConfiguration.class);

    @Value("${druid.datasource.driverClassName}")
    private String driverClassName;

    @Value("${druid.datasource.url}")
    private String url;

    @Value("${druid.datasource.username}")
    private String userName;

    @Value("${druid.datasource.password}")
    private String password;

    @Value("${druid.datasource.initialSize}")
    private int initialSize;

    @Value("${druid.datasource.minIdle}")
    private int minIdle;

    @Value("${druid.datasource.maxActive}")
    private int maxActive;

    @Value("${druid.datasource.maxWait}")
    private long maxWait;

    @Value("${druid.datasource.timeBetweenEvictionRunsMillis}")
    private long timeBetweenEvictionRunsMillis;

    @Value("${druid.datasource.minEvictableIdleTimeMillis}")
    private long minEvictableIdleTimeMillis;

    @Value("${druid.datasource.validationQuery}")
    private String validationQuery;

    @Value("${druid.datasource.testWhileIdle}")
    private boolean testWhileIdle;
    @Value("${druid.datasource.testOnBorrow}")
    private boolean testOnBorrow;

    @Value("${druid.datasource.testOnReturn}")
    private boolean testOnReturn;

    @Value("${druid.datasource.filters}")
    private String filters;

    @Value("${druid.datasource.poolPreparedStatements}")
    private boolean poolPreparedStatements;

    @Value("${druid.datasource.maxPoolPreparedStatementPerConnectionSize}")
    private int maxPoolPreparedStatementPerConnectionSize;



    @Bean
    public DruidDataSource dataSource(){
        DruidDataSource dataSource = new DruidDataSource();

        dataSource.setDriverClassName(driverClassName);
        dataSource.setUrl(url);
        dataSource.setUsername(userName);
        dataSource.setPassword(password);
        //配置初始化大小、最大、最小
        dataSource.setInitialSize(initialSize);
        dataSource.setMinIdle(minIdle);
        dataSource.setMaxActive(maxActive);
        //配置获取连接等待超时的时间
        dataSource.setMaxWait(maxWait);
        //配置间隔多久才进行一次检测，检测需要关闭的空闲连接，单位是毫秒
        dataSource.setTimeBetweenEvictionRunsMillis(timeBetweenEvictionRunsMillis);
        //配置一个连接在池中最小生存的时间，单位是毫秒
        dataSource.setMinEvictableIdleTimeMillis(minEvictableIdleTimeMillis);
        //
        dataSource.setValidationQuery(validationQuery);
        dataSource.setTestWhileIdle(testWhileIdle);
        dataSource.setTestOnBorrow(testOnBorrow);
        dataSource.setTestOnReturn(testOnReturn);

        dataSource.setPoolPreparedStatements(poolPreparedStatements);
        dataSource.setMaxPoolPreparedStatementPerConnectionSize(maxPoolPreparedStatementPerConnectionSize);
        try {
            dataSource.setFilters(filters);
        } catch (SQLException e) {
            //todo 失败是否需要阻止项目启动
            logger.error("druid configuration initialization filter", e);
        }
        //dataSource.setConnectProperties();
        return dataSource;
    }

}
